#ifndef IMAGE_H
#define IMAGE_H

#include "types.h"

extern const u8 TEST_IMAGE[4096];

#endif
