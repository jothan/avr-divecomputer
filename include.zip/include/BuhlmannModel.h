/*
 * BuhlmannModel.h
 *
 *  Created on: 24 févr. 2015
 *      Author: collinm
 */

#ifndef BUHLMANNMODEL_H_
#define BUHLMANNMODEL_H_

#include <array>
#include "CompartmentTissue.h"

using namespace std;


class BuhlmannModel {
public:
	static const int MAX_TISSUE = 16;
	array<CompartmentTissue, MAX_TISSUE> tissue;
	BuhlmannModel();
	virtual ~BuhlmannModel();
};

#endif /* BUHLMANNMODEL_H_ */
