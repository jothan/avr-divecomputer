#ifndef CONSTANTS_H
#define CONSTANTS_H

class GlobalConstants {
  public:
    static const float pressure_water;
    static const float initialAmbienPressure;
    static const float NITROGEN_AIR;
};

#endif
