enum lang { fr, eng};
