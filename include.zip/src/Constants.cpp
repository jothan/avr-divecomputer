#include "Constants.h"

const float GlobalConstants::pressure_water = 0.0627;
const float GlobalConstants::initialAmbienPressure = 1.013;
const float GlobalConstants::NITROGEN_AIR = 0.79;
