#include "configComputer.h"

void ConfigComputer::set_values(char default_lang, int units){

}
