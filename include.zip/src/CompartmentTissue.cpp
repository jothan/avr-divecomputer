/*
 * CompartmentTissue.cpp
 *
 *  Created on: 24 févr. 2015
 *      Author: collinm
 */

#include "CompartmentTissue.h"

CompartmentTissue::CompartmentTissue() {
	// TODO Auto-generated constructor stub

}

CompartmentTissue::~CompartmentTissue() {
	// TODO Auto-generated destructor stub
}

